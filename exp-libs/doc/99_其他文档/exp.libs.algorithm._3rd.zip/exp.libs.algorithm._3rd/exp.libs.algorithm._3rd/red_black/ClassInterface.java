package exp.libs.algorithm._3rd.red_black;

/* ClassInterface.java */

public interface ClassInterface {
	public  double Cost();
	}
