package exp.libs.algorithm._3rd.red_black;


public class nothing {
	
		

public static void main(String [] args){
	System.out.println("Hi, hows it goin?");


	}
}
