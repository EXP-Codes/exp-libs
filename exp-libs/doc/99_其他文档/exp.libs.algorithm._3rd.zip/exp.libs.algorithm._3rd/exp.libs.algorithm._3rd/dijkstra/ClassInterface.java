package exp.libs.algorithm._3rd.dijkstra;
/* ClassInterface.java */

public interface ClassInterface {
	public  double Cost();
	}
