package exp.libs.algorithm._3rd.dijkstra.old;

/* ClassInterface.java */

public interface ClassInterface {
	public  double Cost();
	}
