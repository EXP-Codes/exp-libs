package exp.libs.algorithm._3rd.mst;
/* ClassInterface.java */

public interface ClassInterface {
	public  double Cost();
	}
